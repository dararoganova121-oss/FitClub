<?php
declare(strict_types=1);

header('Content-Type: text/html; charset=utf-8');
session_start();
require __DIR__ . '/config.php';

function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function money($v): string { return number_format((float)$v, 0, ',', ' ') . ' руб.'; }
function go(string $url): never { header("Location: {$url}"); exit; }
function flash(string $type, string $text): void { $_SESSION['flash'][] = compact('type', 'text'); }
function take_flashes(): array { $f = $_SESSION['flash'] ?? []; unset($_SESSION['flash']); return $f; }
function cid(): ?int { return isset($_SESSION['client_id']) ? (int)$_SESSION['client_id'] : null; }
function admin(): bool { return !empty($_SESSION['is_admin']); }
function need_client(): void { if (!cid()) { flash('error', 'Войдите в аккаунт клиента.'); go('?page=login'); } }
function need_admin(): void { if (!admin()) { flash('error', 'Войдите как администратор.'); go('?page=login'); } }
function rows(PDO $pdo, string $sql, array $p = []): array { $s = $pdo->prepare($sql); $s->execute($p); return $s->fetchAll(); }
function row(PDO $pdo, string $sql, array $p = []): ?array { $s = $pdo->prepare($sql); $s->execute($p); return $s->fetch() ?: null; }
function runq(PDO $pdo, string $sql, array $p = []): void { $s = $pdo->prepare($sql); $s->execute($p); }
function fio(array $r): string { return trim(($r['last_name'] ?? '') . ' ' . ($r['first_name'] ?? '') . ' ' . ($r['middle_name'] ?? '')); }
function dmy(?string $d): string { return $d ? date('d.m.Y', strtotime($d)) : ''; }
function dt(?string $d): string { return $d ? date('d.m.Y H:i', strtotime($d)) : ''; }
function valid_session_datetime_parts(string $date, string $time): array {
    if ($date === '') throw new RuntimeException('Укажите дату занятия');
    if ($time === '') throw new RuntimeException('Укажите время занятия');
    if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $date, $dm)) throw new RuntimeException('Некорректная дата или время');
    if (!checkdate((int)$dm[2], (int)$dm[3], (int)$dm[1])) throw new RuntimeException('Некорректная дата или время');
    if (!preg_match('/^([01]\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?$/', $time, $tm)) throw new RuntimeException('Некорректная дата или время');
    return [$date, $tm[1] . ':' . $tm[2] . ':' . ($tm[3] ?? '00')];
}
function has_active_subscription(PDO $pdo, int $clientId): bool {
    return (bool)row($pdo, "SELECT id_subscription FROM subscriptions WHERE id_client=? AND start_date <= CURDATE() AND end_date >= CURDATE() LIMIT 1", [$clientId]);
}

$crud = [
    'clients' => ['title'=>'Клиенты','table'=>'clients','pk'=>'id_client','search'=>['last_name','first_name','middle_name','email','phone'],'cols'=>['id_client'=>'ID','last_name'=>'Фамилия','first_name'=>'Имя','email'=>'Email','phone'=>'Телефон','birth_date'=>'Дата рождения'],'fields'=>[
        'last_name'=>['Фамилия','text',1],'first_name'=>['Имя','text',1],'middle_name'=>['Отчество','text',0],'email'=>['Email','email',1],'password'=>['Пароль','password',0],'phone'=>['Телефон','text',0],'birth_date'=>['Дата рождения','date',0]
    ]],
    'trainers' => ['title'=>'Тренеры','table'=>'trainers','pk'=>'id_trainer','search'=>['last_name','first_name','middle_name','specialization'],'cols'=>['id_trainer'=>'ID','last_name'=>'Фамилия','first_name'=>'Имя','specialization'=>'Специализация','experience'=>'Опыт'],'fields'=>[
        'last_name'=>['Фамилия','text',1],'first_name'=>['Имя','text',1],'middle_name'=>['Отчество','text',0],'specialization'=>['Специализация','text',1],'experience'=>['Опыт, лет','number',1],'education'=>['Образование','text',0],'bio'=>['Био и достижения','textarea',0],'photo_url'=>['Фото URL','text',0]
    ]],
    'subscription_types' => ['title'=>'Типы абонементов','table'=>'subscription_types','pk'=>'id_subscription_type','search'=>['name','description'],'cols'=>['id_subscription_type'=>'ID','name'=>'Название','duration_days'=>'Дней','price'=>'Цена'],'fields'=>[
        'name'=>['Название','text',1],'duration_days'=>['Дней','number',1],'price'=>['Цена','number',1],'description'=>['Описание','textarea',0]
    ]],
    'group_sessions' => ['title'=>'Групповые занятия','table'=>'group_sessions','pk'=>'id_group_session','search'=>['gs.name'],'list'=>"SELECT gs.*, CONCAT(t.last_name,' ',t.first_name) trainer_name, st.name type_name FROM group_sessions gs JOIN trainers t ON t.id_trainer=gs.id_trainer JOIN subscription_types st ON st.id_subscription_type=gs.id_subscription_type",'cols'=>['id_group_session'=>'ID','name'=>'Занятие','session_datetime'=>'Дата','trainer_name'=>'Тренер','type_name'=>'Абонемент'],'fields'=>[
        'name'=>['Название занятия','text',1],'id_trainer'=>['Тренер','select:trainers',1],'id_subscription_type'=>['Тип абонемента','select:subscription_types',1],'session_date'=>['Дата занятия','date',1],'session_time'=>['Время занятия','time',1]
    ]],
    'subscriptions' => ['title'=>'Абонементы клиентов','table'=>'subscriptions','pk'=>'id_subscription','search'=>[],'list'=>"SELECT s.*, CONCAT(c.last_name,' ',c.first_name) client_name, st.name type_name FROM subscriptions s JOIN clients c ON c.id_client=s.id_client JOIN subscription_types st ON st.id_subscription_type=s.id_subscription_type",'cols'=>['id_subscription'=>'ID','client_name'=>'Клиент','type_name'=>'Тип','start_date'=>'Начало','end_date'=>'Окончание'],'fields'=>[
        'start_date'=>['Начало','date',1],'end_date'=>['Окончание','date',1],'id_client'=>['Клиент','select:clients',1],'id_subscription_type'=>['Тип','select:subscription_types',1]
    ]],
    'payments' => ['title'=>'Платежи','table'=>'payments','pk'=>'id_payment','search'=>[],'list'=>"SELECT p.*, CONCAT(c.last_name,' ',c.first_name) client_name, CONCAT('#',s.id_subscription,' ',st.name) sub_label FROM payments p JOIN clients c ON c.id_client=p.id_client JOIN subscriptions s ON s.id_subscription=p.id_subscription JOIN subscription_types st ON st.id_subscription_type=s.id_subscription_type",'cols'=>['id_payment'=>'ID','client_name'=>'Клиент','sub_label'=>'Абонемент','amount'=>'Сумма','payment_date'=>'Дата','is_paid'=>'Оплачен'],'fields'=>[
        'amount'=>['Сумма','number',1],'payment_date'=>['Дата оплаты','datetime-local',1],'is_paid'=>['Оплачен','checkbox',0],'id_client'=>['Клиент','select:clients',1],'id_subscription'=>['Абонемент','select:subscriptions',1]
    ]],
    'session_bookings' => ['title'=>'Записи на занятия','table'=>'session_bookings','pk'=>'id','search'=>[],'list'=>"SELECT sb.*, CONCAT(c.last_name,' ',c.first_name) client_name, CONCAT(gs.name,' - ',DATE_FORMAT(gs.session_datetime,'%d.%m.%Y %H:%i')) session_label FROM session_bookings sb JOIN clients c ON c.id_client=sb.client_id JOIN group_sessions gs ON gs.id_group_session=sb.group_session_id",'cols'=>['id'=>'ID','client_name'=>'Клиент','session_label'=>'Занятие','created_at'=>'Дата записи'],'fields'=>[
        'client_id'=>['Клиент','select:clients',1],'group_session_id'=>['Занятие','select:group_sessions',1],'created_at'=>['Дата записи','datetime-local',1]
    ]],
];

function opts(PDO $pdo, string $src): array {
    return match ($src) {
        'clients' => rows($pdo, "SELECT id_client id, CONCAT(last_name,' ',first_name,' ',COALESCE(middle_name,'')) label FROM clients ORDER BY last_name"),
        'trainers' => rows($pdo, "SELECT id_trainer id, CONCAT(last_name,' ',first_name) label FROM trainers ORDER BY last_name"),
        'subscription_types' => rows($pdo, "SELECT id_subscription_type id, name label FROM subscription_types ORDER BY price DESC"),
        'subscriptions' => rows($pdo, "SELECT s.id_subscription id, CONCAT('#',s.id_subscription,' ',c.last_name,' ',c.first_name,' - ',st.name) label FROM subscriptions s JOIN clients c ON c.id_client=s.id_client JOIN subscription_types st ON st.id_subscription_type=s.id_subscription_type ORDER BY s.id_subscription DESC"),
        'group_sessions' => rows($pdo, "SELECT id_group_session id, CONCAT(name,' - ',DATE_FORMAT(session_datetime,'%d.%m.%Y %H:%i')) label FROM group_sessions ORDER BY session_datetime DESC"),
        default => [],
    };
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form = $_POST['form'] ?? '';
    try {
        if ($form === 'login') {
            $email = trim($_POST['email'] ?? '');
            $pass = (string)($_POST['password'] ?? '');
            if ($email === ADMIN_EMAIL && $pass === ADMIN_PASSWORD) {
                $_SESSION['is_admin'] = true; unset($_SESSION['client_id']);
                flash('success', 'Вы вошли как администратор.'); go('?page=admin');
            }
            $u = row($pdo, "SELECT * FROM clients WHERE email=?", [$email]);
            if (!$u || !password_verify($pass, $u['password'])) throw new RuntimeException('Неверный email или пароль.');
            $_SESSION['client_id'] = (int)$u['id_client']; unset($_SESSION['is_admin']);
            flash('success', 'Вы вошли в личный кабинет.'); go('?page=profile');
        }
        if ($form === 'register') {
            if (strlen((string)($_POST['password'] ?? '')) < 6) throw new RuntimeException('Пароль должен быть не короче 6 символов.');
            runq($pdo, "INSERT INTO clients(last_name,first_name,middle_name,email,password,phone,birth_date) VALUES(?,?,?,?,?,?,?)", [
                trim($_POST['last_name'] ?? ''), trim($_POST['first_name'] ?? ''), trim($_POST['middle_name'] ?? ''), trim($_POST['email'] ?? ''),
                password_hash((string)$_POST['password'], PASSWORD_DEFAULT), trim($_POST['phone'] ?? ''), $_POST['birth_date'] ?: null
            ]);
            $_SESSION['client_id'] = (int)$pdo->lastInsertId(); unset($_SESSION['is_admin']);
            flash('success', 'Регистрация завершена.'); go('?page=profile');
        }
        if ($form === 'logout') { session_destroy(); session_start(); flash('success', 'Вы вышли из аккаунта.'); go('?page=home'); }
        if ($form === 'buy_subscription') {
            need_client();
            $type = row($pdo, "SELECT * FROM subscription_types WHERE id_subscription_type=?", [(int)$_POST['id_subscription_type']]);
            if (!$type) throw new RuntimeException('Абонемент не найден.');
            $start = date('Y-m-d');
            $end = date('Y-m-d', strtotime('+' . (int)$type['duration_days'] . ' days'));
            runq($pdo, "INSERT INTO subscriptions(start_date,end_date,id_client,id_subscription_type) VALUES(?,?,?,?)", [$start,$end,cid(),$type['id_subscription_type']]);
            $sid = (int)$pdo->lastInsertId();
            runq($pdo, "INSERT INTO payments(amount,payment_date,is_paid,id_client,id_subscription) VALUES(?,NOW(),1,?,?)", [$type['price'],cid(),$sid]);
            flash('success', 'Оплата прошла успешно. Абонемент оформлен.'); go('?page=profile');
        }
        if ($form === 'book_session') {
            need_client();
            if (!has_active_subscription($pdo, cid())) {
                flash('error', 'Для записи на занятие нужен активный абонемент.');
                go('?page=subscriptions');
            }
            $sessionId = (int)($_POST['group_session_id'] ?? 0);
            $session = row($pdo, "SELECT id_group_session FROM group_sessions WHERE id_group_session=? AND session_datetime >= NOW()", [$sessionId]);
            if (!$session) throw new RuntimeException('Занятие не найдено или уже прошло.');
            $exists = row($pdo, "SELECT id FROM session_bookings WHERE client_id=? AND group_session_id=?", [cid(), $sessionId]);
            if ($exists) throw new RuntimeException('Вы уже записаны на это занятие.');
            runq($pdo, "INSERT INTO session_bookings(client_id, group_session_id, created_at) VALUES(?,?,NOW())", [cid(), $sessionId]);
            flash('success', 'Запись на занятие сохранена.');
            go('?page=profile');
        }
        if ($form === 'cancel_booking') {
            need_client();
            $bookingId = (int)($_POST['booking_id'] ?? 0);
            runq($pdo, "DELETE FROM session_bookings WHERE id=? AND client_id=?", [$bookingId, cid()]);
            flash('success', 'Запись на занятие отменена.');
            go('?page=profile');
        }
        if ($form === 'crud') {
            need_admin();
            $section = $_POST['section'] ?? 'clients';
            if (!isset($crud[$section])) go('?page=admin');
            $m = $crud[$section]; $id = (int)($_POST['id'] ?? 0);
            if (($_POST['crud_action'] ?? '') === 'delete') {
                runq($pdo, "DELETE FROM {$m['table']} WHERE {$m['pk']}=?", [$id]);
                flash('success', 'Запись удалена.'); go('?page=admin&section=' . urlencode($section));
            }
            if ($section === 'group_sessions') {
                [$sessionDate, $sessionTime] = valid_session_datetime_parts(trim($_POST['session_date'] ?? ''), trim($_POST['session_time'] ?? ''));
                $sessionDatetime = $sessionDate . ' ' . $sessionTime;

                // Проверка ГОД для занятия
                if (!$id && $sessionDatetime < date('Y-m-d H:i:s')) {
                    throw new RuntimeException('Дата и время занятия не могут быть в прошлом. Укажите текущую или будущую дату.');
                }
                
                $values = [
                    trim($_POST['name'] ?? ''),
                    (int)($_POST['id_trainer'] ?? 0),
                    (int)($_POST['id_subscription_type'] ?? 0),
                    $sessionDatetime,
                ];
                
                if ($values[0] === '') throw new RuntimeException('Укажите название занятия');
                if ($id) {
                    runq($pdo, "UPDATE group_sessions SET name=?, id_trainer=?, id_subscription_type=?, session_datetime=? WHERE id_group_session=?", [...$values, $id]);
                    flash('success', 'Занятие обновлено.');
                } else {
                    runq($pdo, "INSERT INTO group_sessions(name,id_trainer,id_subscription_type,session_datetime) VALUES(?,?,?,?)", $values);
                    flash('success', 'Занятие добавлено.');
                }
                go('?page=admin&section=group_sessions');
            }
            $fields = []; $vals = [];
            foreach ($m['fields'] as $name => $f) {
                if ($section === 'clients' && $name === 'password') {
                    $p = trim($_POST['password'] ?? '');
                    if ($p !== '' || !$id) { $fields[] = 'password'; $vals[] = password_hash($p !== '' ? $p : 'client123', PASSWORD_DEFAULT); }
                    continue;
                }
                $type = $f[1];
                $v = $type === 'checkbox' ? (isset($_POST[$name]) ? 1 : 0) : trim((string)($_POST[$name] ?? ''));
                if ($type === 'datetime-local' && $v !== '') $v = str_replace('T', ' ', $v) . ':00';
                $fields[] = $name; $vals[] = $v === '' ? null : $v;
            }
            if ($id) {
                runq($pdo, "UPDATE {$m['table']} SET " . implode(',', array_map(fn($f)=>"$f=?", $fields)) . " WHERE {$m['pk']}=?", [...$vals,$id]);
                flash('success', 'Запись обновлена.');
            } else {
                runq($pdo, "INSERT INTO {$m['table']}(" . implode(',', $fields) . ") VALUES(" . implode(',', array_fill(0,count($fields),'?')) . ")", $vals);
                flash('success', 'Запись добавлена.');
            }
            go('?page=admin&section=' . urlencode($section));
        }
    } catch (Throwable $ex) {
        flash('error', $ex->getMessage());
    }
}

$page = $_GET['page'] ?? 'home';
$navClass = fn(string $p): string => $page === $p ? 'active' : '';
?><!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="color-scheme" content="light">
    <meta name="theme-color" content="#F7EDE2">
    <title>FitClub</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body data-authenticated="<?= cid() ? '1' : '0' ?>">
<div class="page-shell">
<header class="topbar">
    <a class="brand" href="?page=home"><span>FC</span><strong>FitClub</strong></a>
    <button class="nav-toggle" type="button" data-nav-toggle>☰</button>
    <nav class="nav" data-nav>
        <a class="<?= $navClass('home') ?>" href="?page=home">Главная</a><a class="<?= $navClass('subscriptions') ?>" href="?page=subscriptions">Абонементы</a><a class="<?= $navClass('trainers') ?>" href="?page=trainers">Тренеры</a><a class="<?= $navClass('schedule') ?>" href="?page=schedule">Расписание</a>
        <?php if (cid()): ?><a class="<?= $navClass('profile') ?>" href="?page=profile">Профиль</a><?php endif; ?>
        <?php if (admin()): ?><a class="<?= $navClass('admin') ?>" href="?page=admin">Админка</a><a class="<?= $navClass('report') ?>" href="?page=report">Отчёт</a><?php endif; ?>
        <?php if (!cid() && !admin()): ?><a class="nav-cta" href="?page=login">Войти</a><?php else: ?><form method="post" class="inline-form"><input type="hidden" name="form" value="logout"><button class="link-btn">Выйти</button></form><?php endif; ?>
    </nav>
</header>
<div id="flash-area"><?php foreach (take_flashes() as $f): ?><div class="alert <?= e($f['type']) ?>"><?= e($f['text']) ?></div><?php endforeach; ?></div>
<div id="page-content">

<?php if ($page === 'home'):
    $q = trim($_GET['q'] ?? ''); $res = [];
    if ($q !== '') {
        $like = "%$q%";
        $res['Тренеры'] = rows($pdo, "SELECT 'trainer' kind, id_trainer id, CONCAT(last_name,' ',first_name,' ',COALESCE(middle_name,'')) title, specialization text FROM trainers WHERE last_name LIKE ? OR first_name LIKE ? OR specialization LIKE ?", [$like,$like,$like]);
        $res['Абонементы'] = rows($pdo, "SELECT 'subscriptions' kind, id_subscription_type id, name title, description text FROM subscription_types WHERE name LIKE ? OR description LIKE ?", [$like,$like]);
        $res['Занятия'] = rows($pdo, "SELECT 'schedule' kind, id_group_session id, name title, DATE_FORMAT(session_datetime,'%d.%m.%Y %H:%i') text FROM group_sessions WHERE name LIKE ?", [$like]);
    } ?>
<main>
    <section class="hero">
        <div class="hero-text"><p class="eyebrow">Фитнес-клуб во Владимире</p><h1>FitClub</h1><p>Тренируйтесь в комфортном ритме: групповые занятия, сильные тренеры, понятные абонементы и зона восстановления после нагрузок.</p><div class="hero-actions"><a class="btn primary" href="?page=subscriptions">Выбрать абонемент</a><a class="btn secondary" href="?page=schedule">Посмотреть расписание</a></div></div>
        <div class="hero-panel"><div><b>500+</b><span>клиентов выбирают нас для регулярных тренировок</span></div><div><b>20+</b><span>направлений: от пилатеса до единоборств</span></div><div><b>7/7</b><span>работаем каждый день с 7:00 до 23:00</span></div><div><b>SPA</b><span>сауна, хаммам и восстановление в премиум-тарифе</span></div></div>
    </section>
    <section class="section-grid two intro-section"><div><p class="eyebrow">Всё для удобной тренировки</p><h2>Выберите формат, запишитесь на занятие и следите за прогрессом в личном кабинете</h2><p class="muted">На сайте можно посмотреть абонементы, выбрать тренера, найти подходящее занятие в расписании и записаться онлайн. В профиле сохраняются ваши абонементы, оплаты и календарь предстоящих тренировок.</p></div><form class="search-card" method="get"><input type="hidden" name="page" value="home"><label>Найти тренировку, тренера или абонемент</label><div class="search-line"><input name="q" value="<?= e($q) ?>" placeholder="Например: пилатес, самбо, SPA"><button class="btn primary">Найти</button></div></form></section>
    <?php if ($q !== ''): ?><section class="content-section"><h2>Результаты поиска</h2><?php $has=false; foreach ($res as $group=>$items): if ($items): $has=true; ?><h3><?= e($group) ?></h3><div class="cards compact"><?php foreach ($items as $it): ?><a class="card" href="<?= $it['kind']==='trainer' ? '?page=trainer&id='.(int)$it['id'] : '?page='.$it['kind'] ?>"><strong><?= e($it['title']) ?></strong><span><?= e($it['text']) ?></span></a><?php endforeach; ?></div><?php endif; endforeach; if (!$has): ?><div class="empty">Данные не найдены</div><?php endif; ?></section><?php endif; ?>
    <section class="content-section"><div class="section-head"><div><p class="eyebrow">Новости и акции</p><h2>Повод начать уже на этой неделе</h2></div><a class="btn secondary" href="?page=subscriptions">Все абонементы</a></div><div class="cards three"><article class="card accent-yellow"><strong>Пробная неделя для новых клиентов</strong><span>Попробуйте пилатес, зумбу или борьбу на поясах и выберите направление, которое хочется продолжать.</span></article><article class="card accent-green"><strong>Скидка студентам 15%</strong><span>При оформлении месячного абонемента покажите студенческий билет на стойке клуба.</span></article><article class="card accent-coral"><strong>SPA в премиум-тарифе</strong><span>Сауна, хаммам и бассейн помогают восстановиться после интенсивной тренировки.</span></article></div></section>
    <section class="content-section"><div class="section-head"><div><p class="eyebrow">Почему выбирают нас</p><h2>Клуб, в который удобно возвращаться</h2></div></div><div class="feature-row"><div><b>Персональный подход</b><span>Тренеры помогают подобрать нагрузку под цель, опыт и самочувствие.</span></div><div><b>Группы без хаоса</b><span>Расписание понятно заранее, а запись занимает меньше минуты.</span></div><div><b>Сильные направления</b><span>Пилатес, стретчинг, танцы, самбо, дзюдо и функциональные тренировки.</span></div><div><b>Восстановление</b><span>После тренировки можно переключиться в SPA-зоне и спокойно выдохнуть.</span></div></div></section>
    <section class="content-section"><div class="section-head"><div><p class="eyebrow">Популярные направления</p><h2>Тренировки под разное настроение</h2></div><a class="btn secondary" href="?page=schedule">Открыть расписание</a></div><div class="cards four"><article class="program-card"><span>01</span><strong>Пилатес</strong><p>Контроль, осанка и мягкая сила без спешки.</p></article><article class="program-card"><span>02</span><strong>Стретчинг</strong><p>Гибкость, лёгкость движений и восстановление.</p></article><article class="program-card"><span>03</span><strong>Зумба и бачата</strong><p>Кардио, пластика и энергия танцевальной группы.</p></article><article class="program-card"><span>04</span><strong>Самбо и дзюдо</strong><p>Уверенность, техника и функциональная подготовка.</p></article></div></section>
    <section class="content-section location-section"><div class="location-card"><div><p class="eyebrow">Где мы находимся</p><h2>FitClub рядом с остановками и парковкой</h2><p class="muted">Мы находимся в удобном районе Владимира, рядом с остановками и парковкой. Заезжайте после работы, учёбы или в выходной день.</p><div class="contact-grid"><span><b>Адрес</b>г. Владимир, ул. Спортивная, 15</span><span><b>Телефон</b>+7 (495) 123-45-68</span><span><b>Email</b>fitness@mail.ru</span><span><b>WhatsApp/Telegram</b>+7 (999) 888-77-66</span><span><b>Время работы</b>7:00–23:00 без выходных</span></div></div><div class="map-stub" aria-label="Карта расположения FitClub"><span>FitClub</span><small>ул. Спортивная, 15</small></div></div></section>
    <section class="content-section split-cta"><div><p class="eyebrow">Ваш первый шаг</p><h2>Начните с расписания или сразу выберите абонемент</h2><p>Запись на занятия доступна после входа в личный кабинет и оформления активного абонемента.</p></div><div class="hero-actions"><a class="btn primary" href="?page=schedule">Записаться на занятие</a><a class="btn secondary" href="?page=trainers">Познакомиться с тренерами</a></div></section>
</main>

<?php elseif ($page === 'subscriptions'): $types = rows($pdo, "SELECT * FROM subscription_types ORDER BY price DESC"); ?>
<main class="content-section"><div class="section-head"><h1>Абонементы</h1><p>Выберите тариф, а оформление имитирует успешную оплату.</p></div><div class="cards three"><?php foreach ($types as $t): ?><article class="price-card"><h2><?= e($t['name']) ?></h2><div class="price"><?= money($t['price']) ?><span>/ <?= (int)$t['duration_days'] ?> дней</span></div><p><?= e($t['description']) ?></p><form method="post" data-purchase-form data-plan="<?= e($t['name']) ?>" data-price="<?= e(money($t['price'])) ?>"><input type="hidden" name="form" value="buy_subscription"><input type="hidden" name="id_subscription_type" value="<?= (int)$t['id_subscription_type'] ?>"><button class="btn primary full">Купить / оформить</button></form></article><?php endforeach; ?></div></main>

<?php elseif ($page === 'trainers'): $trainers = rows($pdo, "SELECT * FROM trainers ORDER BY last_name"); ?>
<main class="content-section"><div class="section-head"><h1>Тренеры</h1><p>Карточки специалистов с опытом, специализацией и ближайшими занятиями.</p></div><div class="cards two"><?php foreach ($trainers as $t): ?><a class="trainer-card" href="?page=trainer&id=<?= (int)$t['id_trainer'] ?>"><img src="<?= e($t['photo_url']) ?>" alt="<?= e(fio($t)) ?>"><div><h2><?= e(fio($t)) ?></h2><p><?= e($t['specialization']) ?></p><span><?= (int)$t['experience'] ?> лет опыта</span></div></a><?php endforeach; ?></div></main>

<?php elseif ($page === 'trainer'):
    $t = row($pdo, "SELECT * FROM trainers WHERE id_trainer=?", [(int)($_GET['id'] ?? 0)]);
    if (!$t): ?><main class="content-section"><div class="empty">Тренер не найден</div></main><?php else:
    $ss = rows($pdo, "SELECT gs.*, st.name type_name FROM group_sessions gs JOIN subscription_types st ON st.id_subscription_type=gs.id_subscription_type WHERE id_trainer=? AND session_datetime >= NOW() ORDER BY session_datetime LIMIT 8", [$t['id_trainer']]); ?>
<main class="content-section"><a class="back-link" href="?page=trainers">← Все тренеры</a><section class="detail"><img src="<?= e($t['photo_url']) ?>" alt="<?= e(fio($t)) ?>"><div><h1><?= e(fio($t)) ?></h1><p class="tag"><?= e($t['specialization']) ?></p><dl class="facts"><dt>Опыт</dt><dd><?= (int)$t['experience'] ?> лет</dd><dt>Образование</dt><dd><?= e($t['education']) ?></dd></dl><p><?= e($t['bio']) ?></p></div></section><h2>Ближайшие занятия</h2><div class="table-wrap"><table><thead><tr><th>Занятие</th><th>Дата</th><th>Доступно по тарифу</th></tr></thead><tbody><?php foreach ($ss as $s): ?><tr><td><?= e($s['name']) ?></td><td><?= dt($s['session_datetime']) ?></td><td><?= e($s['type_name']) ?></td></tr><?php endforeach; if (!$ss): ?><tr><td colspan="3" class="empty-cell">Данные не найдены</td></tr><?php endif; ?></tbody></table></div></main>
<?php endif; ?>

<?php elseif ($page === 'schedule'):
    $tf = (int)($_GET['trainer'] ?? 0); $query = trim($_GET['query'] ?? ''); $where=[]; $p=[];
    if ($tf) { $where[]='gs.id_trainer=?'; $p[]=$tf; } if ($query !== '') { $where[]='gs.name LIKE ?'; $p[]="%$query%"; }
    $sql = "SELECT gs.*, CONCAT(t.last_name,' ',t.first_name) trainer_name, st.name type_name FROM group_sessions gs JOIN trainers t ON t.id_trainer=gs.id_trainer JOIN subscription_types st ON st.id_subscription_type=gs.id_subscription_type" . ($where ? ' WHERE '.implode(' AND ',$where) : '') . " ORDER BY gs.session_datetime";
    $ss = rows($pdo, $sql, $p);
    $trs = rows($pdo, "SELECT id_trainer, CONCAT(last_name,' ',first_name) name FROM trainers ORDER BY last_name");
    $bookedIds = cid() ? array_column(rows($pdo, "SELECT group_session_id FROM session_bookings WHERE client_id=?", [cid()]), 'group_session_id') : [];
    $hasSub = cid() ? has_active_subscription($pdo, cid()) : false; ?>
<main class="content-section"><div class="section-head"><h1>Расписание</h1><p>Выберите занятие и запишитесь в один клик. Для записи нужен активный абонемент.</p></div><form class="filters" method="get"><input type="hidden" name="page" value="schedule"><select name="trainer"><option value="0">Все тренеры</option><?php foreach ($trs as $tr): ?><option value="<?= (int)$tr['id_trainer'] ?>" <?= $tf===(int)$tr['id_trainer']?'selected':'' ?>><?= e($tr['name']) ?></option><?php endforeach; ?></select><input name="query" value="<?= e($query) ?>" placeholder="Название занятия"><button class="btn primary">Показать</button></form><div class="table-wrap"><table><thead><tr><th>Дата</th><th>Занятие</th><th>Тренер</th><th>Абонемент</th><th>Запись</th></tr></thead><tbody><?php foreach ($ss as $s): $already = in_array($s['id_group_session'], $bookedIds); ?><tr><td><?= dt($s['session_datetime']) ?></td><td><strong><?= e($s['name']) ?></strong></td><td><?= e($s['trainer_name']) ?></td><td><?= e($s['type_name']) ?></td><td><?php if (!cid()): ?><a class="btn tiny secondary" href="?page=login">Войти</a><?php elseif (!$hasSub): ?><a class="btn tiny secondary" href="?page=subscriptions">Оформить абонемент</a><?php elseif ($already): ?><span class="badge ok">Вы записаны</span><?php else: ?><form method="post" data-ajax-form><input type="hidden" name="form" value="book_session"><input type="hidden" name="group_session_id" value="<?= (int)$s['id_group_session'] ?>"><button class="btn tiny primary">Записаться</button></form><?php endif; ?></td></tr><?php endforeach; if (!$ss): ?><tr><td colspan="5" class="empty-cell">Данные не найдены</td></tr><?php endif; ?></tbody></table></div></main>

<?php elseif ($page === 'login' || $page === 'register'): ?>
<main class="auth-layout"><section class="auth-card"><?php if ($page === 'login'): ?><h1>Вход</h1><form method="post" class="form-grid" data-ajax-form><input type="hidden" name="form" value="login"><label>Email<input name="email" type="email" required></label><label>Пароль<input name="password" type="password" required></label><button class="btn primary full">Войти</button></form><p class="muted">Нет аккаунта? <a href="?page=register">Зарегистрироваться</a></p><?php else: ?><h1>Регистрация клиента</h1><form method="post" class="form-grid two-cols" data-ajax-form><input type="hidden" name="form" value="register"><label>Фамилия<input name="last_name" required></label><label>Имя<input name="first_name" required></label><label>Отчество<input name="middle_name"></label><label>Email<input name="email" type="email" required></label><label>Телефон<input name="phone"></label><label>Дата рождения<input name="birth_date" type="date"></label><label class="wide">Пароль<input name="password" type="password" required minlength="6"></label><button class="btn primary full wide">Создать аккаунт</button></form><?php endif; ?></section></main>

<?php elseif ($page === 'profile'):
    need_client();
    $c = row($pdo, "SELECT * FROM clients WHERE id_client=?", [cid()]);
    $subs = rows($pdo, "SELECT s.*, st.name, st.price FROM subscriptions s JOIN subscription_types st ON st.id_subscription_type=s.id_subscription_type WHERE s.id_client=? ORDER BY s.end_date DESC", [cid()]);
    $pays = rows($pdo, "SELECT p.*, st.name sub_name FROM payments p JOIN subscriptions s ON s.id_subscription=p.id_subscription JOIN subscription_types st ON st.id_subscription_type=s.id_subscription_type WHERE p.id_client=? ORDER BY p.payment_date DESC", [cid()]);
    $types = rows($pdo, "SELECT * FROM subscription_types ORDER BY price DESC");
    $bookings = rows($pdo, "SELECT sb.id booking_id, sb.created_at, gs.name, gs.session_datetime, CONCAT(t.last_name,' ',t.first_name) trainer_name FROM session_bookings sb JOIN group_sessions gs ON gs.id_group_session=sb.group_session_id JOIN trainers t ON t.id_trainer=gs.id_trainer WHERE sb.client_id=? ORDER BY gs.session_datetime", [cid()]);
    $upcomingBookings = array_values(array_filter($bookings, fn($b) => strtotime($b['session_datetime']) >= time()));
    $todayBookings = array_values(array_filter($bookings, fn($b) => date('Y-m-d', strtotime($b['session_datetime'])) === date('Y-m-d'))); ?>
    <?php
    $todayDate = date('Y-m-d');
    ?>
<main class="content-section profile-page">
    <div class="section-head"><h1>Профиль клиента</h1><p><?= e(fio($c)) ?> · <?= e($c['email']) ?> · <?= e($c['phone']) ?></p></div>
    <section class="section-grid two">
        <div><h2>Мои абонементы</h2><div class="table-wrap"><table><thead><tr><th>Тип</th><th>Начало</th><th>Окончание</th><th>Статус</th></tr></thead><tbody><?php foreach ($subs as $s): $active=strtotime($s['end_date'])>=strtotime(date('Y-m-d')); ?><tr><td><?= e($s['name']) ?></td><td><?= dmy($s['start_date']) ?></td><td><?= dmy($s['end_date']) ?></td><td><span class="badge <?= $active?'ok':'' ?>"><?= $active?'Активен':'Истёк' ?></span></td></tr><?php endforeach; if (!$subs): ?><tr><td colspan="4" class="empty-cell">Данные не найдены</td></tr><?php endif; ?></tbody></table></div></div>
        <div><h2>Оформить абонемент</h2><div class="mini-list"><?php foreach ($types as $t): ?><form method="post" class="mini-buy" data-purchase-form data-plan="<?= e($t['name']) ?>" data-price="<?= e(money($t['price'])) ?>"><input type="hidden" name="form" value="buy_subscription"><input type="hidden" name="id_subscription_type" value="<?= (int)$t['id_subscription_type'] ?>"><div><strong><?= e($t['name']) ?></strong><span><?= money($t['price']) ?></span></div><button class="btn secondary">Оплатить</button></form><?php endforeach; ?></div></div>
    </section>
    <section class="booking-calendar" data-calendar data-current-month="<?= e(date('Y-m')) ?>" data-today="<?= e($todayDate) ?>">
        <div class="calendar-head"><div><p class="eyebrow">Календарь записей</p><div class="calendar-nav"><button class="calendar-nav-btn" type="button" data-calendar-prev aria-label="Предыдущий месяц">←</button><h2 data-calendar-title></h2><button class="calendar-nav-btn" type="button" data-calendar-next aria-label="Следующий месяц">→</button></div></div><div class="calendar-legend"><span class="today">Сегодня</span><span class="past">Прошедшее</span><span class="future">Предстоящее</span></div></div>
        <div class="calendar-layout">
            <div class="calendar-grid" data-calendar-grid></div>
            <div class="calendar-details">
                <h3>Занятия выбранного дня</h3>
                <div data-calendar-details></div>
            </div>
        </div>
        <div class="calendar-data" hidden>
            <?php foreach ($bookings as $b): ?>
                <div data-calendar-event data-date="<?= e(date('Y-m-d', strtotime($b['session_datetime']))) ?>" data-time="<?= e(dt($b['session_datetime'])) ?>" data-name="<?= e($b['name']) ?>" data-trainer="<?= e($b['trainer_name']) ?>" data-booking-id="<?= (int)$b['booking_id'] ?>" data-future="<?= strtotime($b['session_datetime']) >= time() ? '1' : '0' ?>"></div>
            <?php endforeach; ?>
        </div>
    </section>
    <h2>История оплат</h2><div class="table-wrap"><table><thead><tr><th>Дата</th><th>Абонемент</th><th>Сумма</th><th>Статус</th></tr></thead><tbody><?php foreach ($pays as $p): ?><tr><td><?= dt($p['payment_date']) ?></td><td><?= e($p['sub_name']) ?></td><td><?= money($p['amount']) ?></td><td><?= $p['is_paid']?'Оплачено':'Ожидает' ?></td></tr><?php endforeach; if (!$pays): ?><tr><td colspan="4" class="empty-cell">Данные не найдены</td></tr><?php endif; ?></tbody></table></div>
</main>

<?php elseif ($page === 'admin'):
    need_admin(); $section = $_GET['section'] ?? 'clients'; if (!isset($crud[$section])) $section='clients'; $m=$crud[$section]; $edit=(int)($_GET['edit'] ?? 0); $er=$edit?row($pdo,"SELECT * FROM {$m['table']} WHERE {$m['pk']}=?",[$edit]):[]; $search=trim($_GET['search'] ?? '');
    if ($section === 'group_sessions' && $er && !empty($er['session_datetime'])) { $er['session_date'] = date('Y-m-d', strtotime($er['session_datetime'])); $er['session_time'] = date('H:i', strtotime($er['session_datetime'])); }
    $sql=$m['list'] ?? "SELECT * FROM {$m['table']}"; $p=[]; if ($search!=='' && $m['search']) { $parts=array_map(fn($f)=>"$f LIKE ?", $m['search']); $sql.=' WHERE '.implode(' OR ',$parts); $p=array_fill(0,count($parts),"%$search%"); } $data=rows($pdo,$sql." ORDER BY {$m['pk']} DESC",$p); ?>
<main class="content-section admin-layout"><aside class="admin-menu"><a href="?page=report">Отчёт</a><?php foreach ($crud as $k=>$cm): ?><a class="<?= $section===$k?'active':'' ?>" href="?page=admin&section=<?= e($k) ?>"><?= e($cm['title']) ?></a><?php endforeach; ?></aside><section class="admin-main"><div class="section-head"><h1><?= e($m['title']) ?></h1><p>Добавление, изменение, удаление и поиск записей.</p></div><form method="post" class="crud-form form-grid two-cols"><input type="hidden" name="form" value="crud"><input type="hidden" name="section" value="<?= e($section) ?>"><input type="hidden" name="crud_action" value="save"><input type="hidden" name="id" value="<?= $edit ?>"><?php foreach ($m['fields'] as $name=>$f): [$label,$type,$req]=$f; $val=$er[$name] ?? ''; ?><label class="<?= $type==='textarea'?'wide':'' ?>"><?= e($label) ?><?php if ($type==='textarea'): ?><textarea name="<?= e($name) ?>"><?= e($val) ?></textarea><?php elseif (str_starts_with($type,'select:')): ?><select name="<?= e($name) ?>" <?= $req?'required':'' ?>><?php foreach (opts($pdo, substr($type,7)) as $o): ?><option value="<?= (int)$o['id'] ?>" <?= (string)$val===(string)$o['id']?'selected':'' ?>><?= e($o['label']) ?></option><?php endforeach; ?></select><?php elseif ($type==='checkbox'): ?><span class="checkline"><input type="checkbox" name="<?= e($name) ?>" value="1" <?= $val?'checked':'' ?>> Да</span><?php else: $iv=$type==='datetime-local' && $val ? date('Y-m-d\TH:i', strtotime($val)) : $val; ?><input name="<?= e($name) ?>" type="<?= e($type) ?>" value="<?= e($iv) ?>" <?= $req && $name!=='password'?'required':'' ?> <?= $type==='number' ? 'step="0.01"' : '' ?>><?php endif; ?></label><?php endforeach; ?><div class="wide form-actions"><button class="btn primary"><?= $edit ? 'Сохранить изменения' : ($section === 'group_sessions' ? 'Добавить занятие' : 'Добавить запись') ?></button><?php if ($edit): ?><a class="btn secondary" href="?page=admin&section=<?= e($section) ?>">Отмена</a><?php endif; ?></div></form><form class="filters" method="get"><input type="hidden" name="page" value="admin"><input type="hidden" name="section" value="<?= e($section) ?>"><input name="search" value="<?= e($search) ?>" placeholder="Поиск в разделе"><button class="btn secondary">Найти</button></form><div class="table-wrap"><table><thead><tr><?php foreach ($m['cols'] as $label): ?><th><?= e($label) ?></th><?php endforeach; ?><th>Действия</th></tr></thead><tbody><?php foreach ($data as $r): ?><tr><?php foreach ($m['cols'] as $col=>$label): ?><td><?= in_array($col,['price','amount'],true)?money($r[$col]):e($r[$col] ?? '') ?></td><?php endforeach; ?><td class="actions"><a class="btn tiny secondary" href="?page=admin&section=<?= e($section) ?>&edit=<?= (int)$r[$m['pk']] ?>">Изменить</a><form method="post" data-confirm="Удалить запись?"><input type="hidden" name="form" value="crud"><input type="hidden" name="section" value="<?= e($section) ?>"><input type="hidden" name="crud_action" value="delete"><input type="hidden" name="id" value="<?= (int)$r[$m['pk']] ?>"><button class="btn tiny danger">Удалить</button></form></td></tr><?php endforeach; if (!$data): ?><tr><td colspan="<?= count($m['cols'])+1 ?>" class="empty-cell">Данные не найдены</td></tr><?php endif; ?></tbody></table></div></section></main>

<?php elseif ($page === 'report'):
    need_admin();
    $stats=[
        'clients'=>row($pdo,"SELECT COUNT(*) c FROM clients")['c'],
        'active'=>row($pdo,"SELECT COUNT(*) c FROM subscriptions WHERE end_date >= CURDATE()")['c'],
        'paid'=>row($pdo,"SELECT COALESCE(SUM(amount),0) s FROM payments WHERE is_paid=1")['s'],
        'sessions'=>row($pdo,"SELECT COUNT(*) c FROM group_sessions")['c'],
        'bookings'=>row($pdo,"SELECT COUNT(*) c FROM session_bookings")['c'],
    ];
    $top=rows($pdo,"SELECT st.name, COUNT(*) cnt FROM subscriptions s JOIN subscription_types st ON st.id_subscription_type=s.id_subscription_type GROUP BY st.id_subscription_type ORDER BY cnt DESC");
    $topSessions=rows($pdo,"SELECT gs.name, CONCAT(t.last_name,' ',t.first_name) trainer_name, COUNT(sb.id) cnt FROM group_sessions gs LEFT JOIN session_bookings sb ON sb.group_session_id=gs.id_group_session JOIN trainers t ON t.id_trainer=gs.id_trainer GROUP BY gs.id_group_session ORDER BY cnt DESC, gs.session_datetime LIMIT 6");
    $acs=rows($pdo,"SELECT CONCAT(c.last_name,' ',c.first_name,' ',COALESCE(c.middle_name,'')) client_name, c.phone, st.name, s.end_date FROM subscriptions s JOIN clients c ON c.id_client=s.id_client JOIN subscription_types st ON st.id_subscription_type=s.id_subscription_type WHERE s.end_date >= CURDATE() ORDER BY s.end_date"); ?>
<main class="content-section report"><div class="section-head print-head"><h1>Отчёт администратора</h1><p>Сформирован <?= date('d.m.Y H:i') ?></p><button class="btn primary no-print" type="button" data-print>Распечатать отчёт</button></div><div class="stat-grid five"><div><b><?= (int)$stats['clients'] ?></b><span>Клиентов</span></div><div><b><?= (int)$stats['active'] ?></b><span>Активных абонементов</span></div><div><b><?= money($stats['paid']) ?></b><span>Оплачено</span></div><div><b><?= (int)$stats['sessions'] ?></b><span>Групповых занятий</span></div><div><b><?= (int)$stats['bookings'] ?></b><span>Записей на занятия</span></div></div><section class="section-grid two"><div><h2>Популярные абонементы</h2><div class="mini-list"><?php foreach ($top as $t): ?><div class="mini-buy"><div><strong><?= e($t['name']) ?></strong><span><?= (int)$t['cnt'] ?> покупок</span></div></div><?php endforeach; if (!$top): ?><div class="empty">Данные не найдены</div><?php endif; ?></div></div><div><h2>Популярные тренировки</h2><div class="mini-list"><?php foreach ($topSessions as $s): ?><div class="mini-buy"><div><strong><?= e($s['name']) ?></strong><span><?= e($s['trainer_name']) ?> · <?= (int)$s['cnt'] ?> записей</span></div></div><?php endforeach; if (!$topSessions): ?><div class="empty">Данные не найдены</div><?php endif; ?></div></div></section><h2>Клиенты с активными абонементами</h2><div class="table-wrap"><table><thead><tr><th>Клиент</th><th>Телефон</th><th>Абонемент</th><th>До</th></tr></thead><tbody><?php foreach ($acs as $a): ?><tr><td><?= e($a['client_name']) ?></td><td><?= e($a['phone']) ?></td><td><?= e($a['name']) ?></td><td><?= dmy($a['end_date']) ?></td></tr><?php endforeach; if (!$acs): ?><tr><td colspan="4" class="empty-cell">Данные не найдены</td></tr><?php endif; ?></tbody></table></div></main>

<?php else: ?><main class="content-section"><div class="empty">Страница не найдена</div></main><?php endif; ?>
</div>

<footer class="footer"><div><strong>FitClub</strong><span>Фитнес, групповые занятия и восстановление во Владимире</span></div><div>+7 (495) 123-45-68 · fitness@mail.ru · WhatsApp/Telegram: +7 (999) 888-77-66 · г. Владимир, ул. Спортивная, 15 · 7:00-23:00 без выходных</div></footer>
<div class="payment-modal" data-payment-modal aria-hidden="true">
    <div class="payment-card" role="dialog" aria-modal="true" aria-labelledby="payment-title">
        <button class="payment-close" type="button" data-payment-close aria-label="Закрыть">×</button>
        <div class="payment-icon" data-payment-icon></div>
        <p class="eyebrow">Оформление абонемента</p>
        <h2 id="payment-title">Подтвердите покупку</h2>
        <p class="payment-plan" data-payment-plan></p>
        <div class="payment-steps" data-payment-steps>
            <span>Проверяем данные</span>
            <span>Оформляем абонемент</span>
            <span>Оплата успешно выполнена</span>
        </div>
        <div class="payment-actions" data-payment-actions>
            <button class="btn secondary" type="button" data-payment-cancel>Отмена</button>
            <button class="btn primary" type="button" data-payment-confirm>Подтвердить</button>
        </div>
    </div>
</div>
</div>
<script src="assets/app.js"></script>
</body>
</html>
