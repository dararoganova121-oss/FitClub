(() => {
    const allowedPages = new Set([
        'home',
        'subscriptions',
        'trainers',
        'trainer',
        'schedule',
        'login',
        'register',
        'profile',
        'admin',
        'report',
    ]);

    const pageContent = () => document.querySelector('#page-content');
    const flashArea = () => document.querySelector('#flash-area');
    const nav = () => document.querySelector('[data-nav]');

    const isPjaxUrl = (url) => {
        if (url.origin !== window.location.origin) return false;
        if (url.hash && url.pathname === window.location.pathname && url.search === window.location.search) return false;
        const page = url.searchParams.get('page') || 'home';
        return allowedPages.has(page);
    };

    const setContentLoading = (loading) => {
        const content = pageContent();
        if (content) content.classList.toggle('is-loading', loading);
    };

    const updateActiveNav = (url) => {
        const page = url.searchParams.get('page') || 'home';
        document.querySelectorAll('.nav a').forEach((link) => {
            try {
                const linkUrl = new URL(link.href, window.location.href);
                link.classList.toggle('active', (linkUrl.searchParams.get('page') || 'home') === page);
            } catch {
                link.classList.remove('active');
            }
        });
        nav()?.classList.remove('open');
    };

    const applyDocument = (html, url, push = true) => {
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const nextContent = doc.querySelector('#page-content');
        if (!nextContent) throw new Error('PJAX content not found');

        const currentContent = pageContent();
        if (!currentContent) throw new Error('Current content not found');
        currentContent.replaceWith(nextContent);

        const nextFlash = doc.querySelector('#flash-area');
        if (nextFlash && flashArea()) flashArea().replaceWith(nextFlash);

        const nextHeader = doc.querySelector('.topbar');
        const currentHeader = document.querySelector('.topbar');
        if (nextHeader && currentHeader) currentHeader.replaceWith(nextHeader);

        const nextFooter = doc.querySelector('.footer');
        const currentFooter = document.querySelector('.footer');
        if (nextFooter && currentFooter) currentFooter.replaceWith(nextFooter);

        document.body.dataset.authenticated = doc.body?.dataset?.authenticated || '0';
        document.title = doc.title || document.title;
        if (push) history.pushState({ pjax: true }, '', url.href);
        updateActiveNav(url);
        initCalendars();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const loadPage = async (href, push = true) => {
        const url = new URL(href, window.location.href);
        if (!isPjaxUrl(url)) {
            window.location.href = url.href;
            return;
        }
        try {
            setContentLoading(true);
            const response = await fetch(url.href, {
                method: 'GET',
                headers: { 'X-Requested-With': 'fetch' },
                credentials: 'same-origin',
            });
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const html = await response.text();
            applyDocument(html, new URL(response.url), push);
        } catch {
            window.location.href = url.href;
        } finally {
            setContentLoading(false);
        }
    };

    const fetchFormAndApply = async (form, submitter = null) => {
        const url = new URL(form.action || window.location.href, window.location.href);
        const formData = new FormData(form);
        if (submitter?.name) formData.append(submitter.name, submitter.value);
        try {
            setContentLoading(true);
            const response = await fetch(url.href, {
                method: form.method || 'POST',
                body: formData,
                headers: { 'X-Requested-With': 'fetch' },
                credentials: 'same-origin',
            });
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const html = await response.text();
            applyDocument(html, new URL(response.url), true);
        } catch {
            form.submit();
        } finally {
            setContentLoading(false);
        }
    };

    const setButtonLoading = (button, loading) => {
        if (!button) return;
        if (loading) {
            button.disabled = true;
            button.classList.add('is-loading');
            button.dataset.oldText = button.textContent;
            button.textContent = 'Загрузка...';
        } else {
            button.disabled = false;
            button.classList.remove('is-loading');
            if (button.dataset.oldText) button.textContent = button.dataset.oldText;
        }
    };

    const monthNames = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
    const weekdays = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
    const escapeHtml = (value) => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#039;');
    const getCalendarEvents = (calendar) => Array.from(calendar.querySelectorAll('[data-calendar-event]')).map((item) => ({
        date: item.dataset.date,
        time: item.dataset.time,
        name: item.dataset.name,
        trainer: item.dataset.trainer,
        bookingId: item.dataset.bookingId,
        future: item.dataset.future === '1',
    }));
    const groupEventsByDate = (events) => events.reduce((acc, item) => {
        if (!acc[item.date]) acc[item.date] = [];
        acc[item.date].push(item);
        return acc;
    }, {});

    const renderCalendarDetails = (calendar, date) => {
        const details = calendar.querySelector('[data-calendar-details]');
        if (!details) return;
        const events = getCalendarEvents(calendar);
        const grouped = groupEventsByDate(events);
        const month = calendar.dataset.currentMonth;
        const monthHasEvents = events.some((event) => event.date.startsWith(month));
        const items = date ? (grouped[date] || []) : [];
        if (!monthHasEvents) {
            details.innerHTML = '<div class="empty">В этом месяце записей нет</div>';
            return;
        }
        if (!date || !items.length) {
            details.innerHTML = '<div class="empty">Выберите день с отметкой в календаре</div>';
            return;
        }
        details.innerHTML = `
            <div class="calendar-day-list active">
                <strong>${escapeHtml(date.split('-').reverse().join('.'))}</strong>
                ${items.map((item) => `
                    <form method="post" class="mini-buy" data-ajax-form data-confirm="Отменить запись на занятие?">
                        <input type="hidden" name="form" value="cancel_booking">
                        <input type="hidden" name="booking_id" value="${escapeHtml(item.bookingId)}">
                        <div><strong>${escapeHtml(item.name)}</strong><span>${escapeHtml(item.time)} · ${escapeHtml(item.trainer)}</span></div>
                        ${item.future ? '<button class="btn danger tiny">Отменить</button>' : '<span class="badge">Прошло</span>'}
                    </form>
                `).join('')}
            </div>
        `;
    };

    const renderCalendar = (calendar) => {
        const grid = calendar.querySelector('[data-calendar-grid]');
        const title = calendar.querySelector('[data-calendar-title]');
        if (!grid || !title) return;
        const [year, month] = calendar.dataset.currentMonth.split('-').map(Number);
        const today = calendar.dataset.today;
        const events = getCalendarEvents(calendar);
        const grouped = groupEventsByDate(events);
        const monthKey = `${year}-${String(month).padStart(2, '0')}`;
        const monthEventDates = Object.keys(grouped).filter((date) => date.startsWith(monthKey)).sort();
        const firstDate = new Date(year, month - 1, 1);
        const firstWeekday = firstDate.getDay() === 0 ? 7 : firstDate.getDay();
        const daysInMonth = new Date(year, month, 0).getDate();
        const selectedDate = monthEventDates.includes(today) ? today : (monthEventDates[0] || '');
        title.textContent = `${monthNames[month - 1]} ${year}`;
        grid.innerHTML = weekdays.map((day) => `<div class="calendar-weekday">${day}</div>`).join('');
        for (let blank = 1; blank < firstWeekday; blank += 1) {
            grid.insertAdjacentHTML('beforeend', '<div class="calendar-day empty-day"></div>');
        }
        for (let day = 1; day <= daysInMonth; day += 1) {
            const date = `${monthKey}-${String(day).padStart(2, '0')}`;
            const items = grouped[date] || [];
            const state = date === today ? 'today' : (date < today ? 'past' : 'future');
            grid.insertAdjacentHTML('beforeend', `
                <button class="calendar-day ${items.length ? 'has-bookings' : ''} ${state} ${date === selectedDate ? 'selected' : ''}" type="button" data-calendar-day="${date}">
                    <span>${day}</span>
                    ${items.length ? `<i>${items.length}</i>` : ''}
                </button>
            `);
        }
        renderCalendarDetails(calendar, selectedDate);
    };

    const initCalendars = () => document.querySelectorAll('[data-calendar]').forEach(renderCalendar);

    const modal = () => document.querySelector('[data-payment-modal]');
    const modalIcon = () => document.querySelector('[data-payment-icon]');
    let pendingPurchaseForm = null;

    const resetPaymentModal = () => {
        const title = document.querySelector('#payment-title');
        const icon = modalIcon();
        const actions = document.querySelector('[data-payment-actions]');
        if (title) title.textContent = 'Подтвердите покупку';
        if (icon) icon.className = 'payment-icon';
        document.querySelectorAll('[data-payment-steps] span').forEach((step) => step.classList.remove('active', 'done'));
        if (actions) actions.hidden = false;
    };

    const closePaymentModal = () => {
        const box = modal();
        if (!box) return;
        box.classList.remove('open');
        box.setAttribute('aria-hidden', 'true');
        pendingPurchaseForm = null;
        resetPaymentModal();
    };

    const openPaymentModal = (form) => {
        if (document.body.dataset.authenticated !== '1') {
            loadPage('?page=login', true);
            return false;
        }
        const box = modal();
        if (!box) return false;
        pendingPurchaseForm = form;
        resetPaymentModal();
        const plan = form.dataset.plan || 'абонемент';
        const price = form.dataset.price || '';
        const planNode = document.querySelector('[data-payment-plan]');
        if (planNode) planNode.textContent = price ? `${plan} · ${price}` : plan;
        box.classList.add('open');
        box.setAttribute('aria-hidden', 'false');
        return true;
    };

    const runPaymentAnimation = () => {
        if (!pendingPurchaseForm) return;
        const title = document.querySelector('#payment-title');
        const icon = modalIcon();
        const actions = document.querySelector('[data-payment-actions]');
        const steps = Array.from(document.querySelectorAll('[data-payment-steps] span'));
        const messages = ['Проверяем данные...', 'Оформляем абонемент...', 'Оплата успешно выполнена'];
        if (actions) actions.hidden = true;
        if (title) title.textContent = 'Оформляем абонемент...';
        icon?.classList.add('loading');

        steps.forEach((step, index) => {
            window.setTimeout(() => {
                steps.forEach((item, itemIndex) => {
                    item.classList.toggle('done', itemIndex < index);
                    item.classList.toggle('active', itemIndex === index);
                });
                if (title) title.textContent = messages[index];
                if (index === steps.length - 1) {
                    icon?.classList.remove('loading');
                    icon?.classList.add('success');
                    window.setTimeout(async () => {
                        const form = pendingPurchaseForm;
                        closePaymentModal();
                        if (form) await fetchFormAndApply(form);
                    }, 650);
                }
            }, index * 800);
        });
    };

    document.addEventListener('click', (event) => {
        const navButton = event.target.closest('[data-nav-toggle]');
        if (navButton) {
            nav()?.classList.toggle('open');
            return;
        }

        if (event.target.closest('[data-print]')) {
            window.print();
            return;
        }

        if (event.target.closest('[data-payment-confirm]')) {
            runPaymentAnimation();
            return;
        }
        if (event.target.closest('[data-payment-cancel], [data-payment-close]')) {
            closePaymentModal();
            return;
        }
        const box = modal();
        if (box && event.target === box && !modalIcon()?.classList.contains('loading')) {
            closePaymentModal();
            return;
        }
        const calendarDay = event.target.closest('[data-calendar-day]');
        if (calendarDay) {
            const calendar = calendarDay.closest('[data-calendar]');
            if (!calendar || calendarDay.classList.contains('empty-day')) return;
            calendar.querySelectorAll('[data-calendar-day]').forEach((day) => day.classList.toggle('selected', day === calendarDay));
            renderCalendarDetails(calendar, calendarDay.dataset.calendarDay);
            return;
        }

        const calendarPrev = event.target.closest('[data-calendar-prev]');
        const calendarNext = event.target.closest('[data-calendar-next]');
        if (calendarPrev || calendarNext) {
            const calendar = event.target.closest('[data-calendar]');
            if (!calendar) return;
            const [year, month] = calendar.dataset.currentMonth.split('-').map(Number);
            const nextMonth = new Date(year, month - 1 + (calendarNext ? 1 : -1), 1);
            calendar.dataset.currentMonth = `${nextMonth.getFullYear()}-${String(nextMonth.getMonth() + 1).padStart(2, '0')}`;
            renderCalendar(calendar);
            return;
        }

        const link = event.target.closest('a[href]');
        if (!link) return;
        if (event.defaultPrevented || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
        if (link.target === '_blank' || link.hasAttribute('download') || link.dataset.noPjax !== undefined) return;
        const url = new URL(link.href, window.location.href);
        if (!isPjaxUrl(url)) return;
        event.preventDefault();
        loadPage(url.href, true);
    });

    document.addEventListener('submit', async (event) => {
        const form = event.target;
        if (!(form instanceof HTMLFormElement)) return;

        if ((form.method || 'get').toLowerCase() === 'get' && !form.dataset.noPjax) {
            const url = new URL(form.action || window.location.href, window.location.href);
            new FormData(form).forEach((value, key) => url.searchParams.set(key, value));
            if (isPjaxUrl(url)) {
                event.preventDefault();
                await loadPage(url.href, true);
                return;
            }
        }

        if (form.matches('[data-purchase-form]')) {
            event.preventDefault();
            openPaymentModal(form);
            return;
        }

        const text = form.getAttribute('data-confirm');
        if (text && !window.confirm(text)) {
            event.preventDefault();
            return;
        }

        if (form.matches('[data-ajax-form]')) {
            event.preventDefault();
            await fetchFormAndApply(form, event.submitter);
            return;
        }

        setButtonLoading(event.submitter, true);
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && modal()?.classList.contains('open') && !modalIcon()?.classList.contains('loading')) {
            closePaymentModal();
        }
        if (event.key === 'Escape' && event.target.matches('input[name="query"], input[name="search"]')) {
            event.target.value = '';
            event.target.form?.requestSubmit();
        }
    });

    window.addEventListener('popstate', () => loadPage(window.location.href, false));
    initCalendars();
})();
